class Edge { // Each Edge Connection
    int start;
    int end;
}
