class Point { // Each vertex
    int index;
}
